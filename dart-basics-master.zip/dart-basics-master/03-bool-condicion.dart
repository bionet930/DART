void main() {
  
  
  bool? isActive = null;
  
  if ( isActive == null ) {
    print( 'isActive es null' );
  } else {
    print( 'No es null' );
  }
  
  
}
