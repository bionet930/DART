# Dart Basics
Un repositorio con los ejercicios de reforzamiento de Dart para el curso de Flutter

[Dart de cero hasta los detalles](https://fernando-herrera.com/#/search/dart)